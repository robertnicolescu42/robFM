export class Environment{
    lastFMApiKey: string = 'f9a5d8edbdc0c6fe751b943d76d9b241';
    firebaseApiKey: string = 'AIzaSyA054d2GqqlK-Jg29XK7iwP4jYmVpilvbE';
}